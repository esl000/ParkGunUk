#pragma once
#include "stdafx.h"

class cNetworkPlayer
{
	SOCKET m_PlayerSocket;
	class iPlayerDelegate* m_Delegate;
	
	char m_RecvBuf[SIZE_BUF];
	char m_SendBuf[SIZE_BUF];

	std::mutex m_PlayerMutex;
	std::thread* m_PlayerThread;
public:
	cNetworkPlayer();
	~cNetworkPlayer();

	void Start(SOCKET& sock);
	void RunThread();

	void ChangeToData();

	class iPlayerDelegate* Delegate() const { return m_Delegate; }
	void Delegate(class iPlayerDelegate* val) { m_Delegate = val; }

	std::thread* PlayerThread() const { return m_PlayerThread; }
	void PlayerThread(std::thread* val) { m_PlayerThread = val; }
};

