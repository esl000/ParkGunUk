#include "stdafx.h"
#include "cNetworkPlayer.h"


cNetworkPlayer::cNetworkPlayer()
{
}


cNetworkPlayer::~cNetworkPlayer()
{
	//m_PlayerThread->join();
	//thread	std::thread::native_handle_type threadHandle = m_PlayerThread->native_handle();

	delete m_PlayerThread;
}

void cNetworkPlayer::Start(SOCKET& sock)
{
	m_PlayerSocket = sock;
	m_PlayerThread = new std::thread([&]() {RunThread(); });
}

void cNetworkPlayer::RunThread()
{
	char buf[SIZE_BUF];
	memset(buf, 0, SIZE_BUF);
	while (true)
	{
		m_PlayerMutex.lock();
		recv(m_PlayerSocket, m_RecvBuf, SIZE_BUF, 0);
		m_PlayerMutex.unlock();
		ChangeToData();
		send(m_PlayerSocket, buf, SIZE_BUF, 0);
	}
}

void cNetworkPlayer::ChangeToData()
{
	char tempData[SIZE_BUF];
	memcpy(tempData, m_RecvBuf, SIZE_BUF);
}
