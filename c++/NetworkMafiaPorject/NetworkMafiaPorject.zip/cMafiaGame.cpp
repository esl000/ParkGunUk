#include "stdafx.h"
#include "cMafiaGame.h"
#include "cNetworkPlayer.h"


cMafiaGame::cMafiaGame()
{
}


cMafiaGame::~cMafiaGame()
{
}

cMafiaGame* cMafiaGame::GetInstance()
{
	static cMafiaGame instance;
	return &instance;
}

void cMafiaGame::GameStart()
{

}

void cMafiaGame::ConnectSocket(SOCKET& clientSocket)
{
	cNetworkPlayer* player = new cNetworkPlayer;
	RegisterGame(player);
	m_vecPlayer.insert(player);
	player->Start(clientSocket);
}

void cMafiaGame::RegisterGame(cNetworkPlayer* player)
{
	player->Delegate(this);
}

void cMafiaGame::UnRegisterGame(cNetworkPlayer* player)
{
	m_vecPlayer.erase(player);
}

void cMafiaGame::AddMessage(cNetworkPlayer* player, std::string message)
{

}
