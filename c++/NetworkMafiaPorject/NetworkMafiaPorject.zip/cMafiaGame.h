#pragma once
#include "stdafx.h"


#define g_Game cMafiaGame::GetInstance()

class iPlayerDelegate
{
	virtual void RegisterGame(class cNetworkPlayer* player) = 0;
	virtual void UnRegisterGame(cNetworkPlayer* player) = 0;
	virtual void AddMessage(cNetworkPlayer* player, std::string message) = 0;

};


class cMafiaGame : public iPlayerDelegate
{
	cMafiaGame();

	std::set<class cNetworkPlayer*> m_vecPlayer;

public:
	~cMafiaGame();

	static cMafiaGame* GetInstance();

	void GameStart();
	void ConnectSocket(SOCKET& clientSocket);

	virtual void RegisterGame(cNetworkPlayer* player) override;
	virtual void UnRegisterGame(cNetworkPlayer* player) override;
	virtual void AddMessage(cNetworkPlayer* player, std::string message) override;
};

